#!/bin/bash
echo starting
